#include <stdio.h>
#include "stack.h"
int main(int argc, char const *argv[]){
    Stack S;
    makeNullStack(&S);
    
    return 0;
}