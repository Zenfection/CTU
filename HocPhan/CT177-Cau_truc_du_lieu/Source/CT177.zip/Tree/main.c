#include <stdio.h>
#include "treeBST.h"
//#include "treeAVL.h"
int main(int argc, char const *argv[]){
    
    return 0;
}

